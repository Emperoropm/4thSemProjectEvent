document.addEventListener("DOMContentLoaded", function () {
    document.body.style.display = "block";
});